#!/usr/bin/env node
/* Birds World — dataset + SEO builder.
 *
 * Pulls the accepted bird species (class Aves) from the GBIF backbone, adds
 * English/Arabic names and a Wikimedia Commons photo from Wikidata, then writes:
 *   birds.json            compact dataset the app loads at start-up
 *   birds/<slug>.html     one crawlable static page per species (JSON-LD included)
 *   birds/index.html      crawlable index of every species, grouped by order
 *   sitemap.xml, robots.txt
 *
 * Nothing is invented: a field that the sources do not have stays empty.
 *
 * Usage (Node 18+):
 *   SITE_URL=https://YOURNAME.github.io/birds-world LIMIT=6000 node scripts/build-birds.cjs
 *   LIMIT=0 means "every accepted species" (about 11,000).
 */
"use strict";
const fs = require("fs"), path = require("path");

const ROOT = path.resolve(process.env.OUT_DIR || path.join(__dirname, ".."));
const SITE = (process.env.SITE_URL || "").replace(/\/+$/, "");
const LIMIT = process.env.LIMIT === undefined ? 6000 : parseInt(process.env.LIMIT, 10) || 0;
const GBIF = "https://api.gbif.org/v1";
const BACKBONE = "d7dddbf4-2cf0-4f39-9b2a-bb099caae36c";
const AVES = 212;
const UA = "BirdsWorldBuilder/1.0 (static site build; https://github.com/)";
const sleep = ms => new Promise(r => setTimeout(r, ms));
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const slug = s => String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

async function getJSON(url, tries = 6) {
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" } });
      if (res.ok) return await res.json();
      if (res.status !== 429 && res.status < 500) throw new Error("HTTP " + res.status + " " + url.slice(0, 120));
    } catch (e) { if (i === tries - 1) throw e; }
    await sleep(1500 * (i + 1) * (i + 1));
  }
  throw new Error("gave up: " + url.slice(0, 120));
}

/* ---------- 1. species list from GBIF ---------- */
async function fromGBIF() {
  const rows = new Map();
  for (let offset = 0; ; offset += 1000) {
    const j = await getJSON(GBIF + "/species/search?datasetKey=" + BACKBONE + "&highertaxonKey=" + AVES +
      "&rank=SPECIES&status=ACCEPTED&limit=1000&offset=" + offset);
    for (const r of j.results || []) {
      const sci = r.canonicalName;
      if (!sci || !/^[A-Z][a-z-]+ [a-z-]+$/.test(sci) || rows.has(sci)) continue;
      const eng = (r.vernacularNames || []).find(v => v.language === "eng");
      rows.set(sci, { sci, genus: r.genus || sci.split(" ")[0], family: r.family || "", order: r.order || "",
        gbif: r.key, fk: r.familyKey || 0, en: eng ? eng.vernacularName : "", ar: "", file: "", wd: "" });
    }
    process.stdout.write("\rGBIF: " + rows.size + " species");
    if (j.endOfRecords || !(j.results || []).length) break;
    await sleep(120);
  }
  console.log();
  return [...rows.values()];
}

/* ---------- 2. names + photo from Wikidata ---------- */
async function enrich(rows) {
  const BATCH = 80;
  const batches = [];
  for (let i = 0; i < rows.length; i += BATCH) batches.push(rows.slice(i, i + BATCH));
  const bySci = new Map(rows.map(r => [r.sci, r]));
  let done = 0;
  async function work(batch) {
    const values = batch.map(r => '"' + r.sci + '"').join(" ");
    const q = "SELECT ?sci (SAMPLE(?i) AS ?item) (SAMPLE(?l1) AS ?en1) (SAMPLE(?c1) AS ?en2) (SAMPLE(?l2) AS ?ar1) (SAMPLE(?c2) AS ?ar2) (SAMPLE(?p) AS ?img) WHERE { " +
      "VALUES ?sci { " + values + " } ?i wdt:P225 ?sci . " +
      'OPTIONAL { ?i rdfs:label ?l1 FILTER(lang(?l1)="en") } ' +
      'OPTIONAL { ?i wdt:P1843 ?c1 FILTER(lang(?c1)="en") } ' +
      'OPTIONAL { ?i rdfs:label ?l2 FILTER(lang(?l2)="ar") } ' +
      'OPTIONAL { ?i wdt:P1843 ?c2 FILTER(lang(?c2)="ar") } ' +
      "OPTIONAL { ?i wdt:P18 ?p } } GROUP BY ?sci";
    let j;
    try { j = await getJSON("https://query.wikidata.org/sparql?format=json&query=" + encodeURIComponent(q)); }
    catch (e) { console.warn("\nWikidata batch skipped:", e.message); return; }
    for (const b of j.results.bindings) {
      const r = bySci.get(b.sci.value); if (!r) continue;
      const v = k => (b[k] && b[k].value) || "";
      r.wd = v("item").split("/").pop();
      const en = v("en2") || r.en || (v("en1") !== r.sci ? v("en1") : "");
      r.en = en;
      r.ar = v("ar2") || v("ar1");
      const img = v("img");
      if (img) r.file = decodeURIComponent(img.split("/").pop()).replace(/_/g, " ");
    }
    done++; process.stdout.write("\rWikidata: " + done + "/" + batches.length + " batches");
  }
  const pool = 2; let next = 0;
  await Promise.all(Array.from({ length: pool }, async () => { while (next < batches.length) { const b = batches[next++]; await work(b); await sleep(400); } }));
  console.log();
}

/* ---------- 3. outputs ---------- */
const thumb = (file, px) => "https://commons.wikimedia.org/wiki/Special:FilePath/" + encodeURIComponent(file.replace(/ /g, "_")) + "?width=" + px;

function pageHTML(r) {
  const name = r.en || r.sci;
  const url = SITE ? SITE + "/birds/" + r.slug + ".html" : "";
  const desc = name + (r.en ? " (" + r.sci + ")" : "") + " is a bird species" +
    (r.family ? " in the family " + r.family : "") + (r.order ? ", order " + r.order : "") + "." +
    (r.ar ? " Arabic name: " + r.ar + "." : "") + " Open the Birds World guide for the full atlas, photos and care tools.";
  const ld = { "@context": "https://schema.org", "@type": "Taxon", name, alternateName: [r.sci, r.ar].filter(Boolean),
    taxonRank: "species", parentTaxon: r.genus ? { "@type": "Taxon", name: r.genus, taxonRank: "genus" } : undefined,
    image: r.file ? thumb(r.file, 800) : undefined, url: url || undefined,
    sameAs: ["https://www.gbif.org/species/" + r.gbif].concat(r.wd ? ["https://www.wikidata.org/wiki/" + r.wd] : []) };
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(name)}${r.en ? " (" + esc(r.sci) + ")" : ""} — Birds World</title>
<meta name="description" content="${esc(desc)}">
${url ? `<link rel="canonical" href="${esc(url)}">\n` : ""}<meta property="og:title" content="${esc(name)} — Birds World"><meta property="og:description" content="${esc(desc)}"><meta property="og:type" content="article">
${r.file ? `<meta property="og:image" content="${esc(thumb(r.file, 800))}">\n` : ""}<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, "\\u003c")}</script>
<style>body{font:16px/1.65 system-ui,"Noto Sans Arabic",sans-serif;max-width:760px;margin:0 auto;padding:20px;color:#0f172a;background:#f8fafc}
a{color:#047857}img{max-width:100%;height:auto;border-radius:14px}dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 16px}dt{color:#64748b}
.btn{display:inline-block;background:#10b981;color:#fff;padding:10px 18px;border-radius:999px;text-decoration:none;font-weight:600}
@media(prefers-color-scheme:dark){body{background:#0b1220;color:#e2e8f0}a{color:#34d399}dt{color:#94a3b8}}</style></head>
<body><nav><a href="../index.html">Birds World</a> › <a href="index.html">All species</a></nav>
<h1>${esc(name)}</h1><p><i>${esc(r.sci)}</i>${r.ar ? " — <span lang=\"ar\" dir=\"rtl\">" + esc(r.ar) + "</span>" : ""}</p>
${r.file ? `<img src="${esc(thumb(r.file, 800))}" alt="${esc(name)} (${esc(r.sci)})" loading="lazy" width="760">\n<p><small>Photo: Wikimedia Commons, file “${esc(r.file)}”. See the file page for author and licence.</small></p>` : ""}
<dl><dt>Scientific name</dt><dd><i>${esc(r.sci)}</i></dd><dt>Genus</dt><dd>${esc(r.genus)}</dd><dt>Family</dt><dd>${esc(r.family)}</dd><dt>Order</dt><dd>${esc(r.order)}</dd></dl>
<p><a class="btn" href="../index.html#/atlas/${encodeURIComponent(r.sci)}">Open in the guide</a></p>
<p><a href="https://www.gbif.org/species/${r.gbif}" rel="noopener">GBIF record</a>${r.wd ? ` · <a href="https://www.wikidata.org/wiki/${esc(r.wd)}" rel="noopener">Wikidata</a>` : ""}</p>
</body></html>
`;
}

function indexHTML(rows) {
  const byOrder = new Map();
  rows.forEach(r => { const k = r.order || "Other"; if (!byOrder.has(k)) byOrder.set(k, []); byOrder.get(k).push(r); });
  const body = [...byOrder.keys()].sort().map(o => `<h2>${esc(o)}</h2><ul>` +
    byOrder.get(o).map(r => `<li><a href="${r.slug}.html">${esc(r.en || r.sci)}</a>${r.en ? " <i>" + esc(r.sci) + "</i>" : ""}</li>`).join("") + "</ul>").join("\n");
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>All ${rows.length} bird species — Birds World</title>
<meta name="description" content="Browse ${rows.length} bird species by order, with scientific names and photos from Wikimedia Commons.">
${SITE ? `<link rel="canonical" href="${SITE}/birds/">` : ""}
<style>body{font:16px/1.7 system-ui,sans-serif;max-width:900px;margin:0 auto;padding:20px}ul{columns:2 260px}a{color:#047857}</style></head>
<body><p><a href="../index.html">← Birds World</a></p><h1>All ${rows.length} bird species</h1>${body}</body></html>
`;
}

(async () => {
  console.log("Output folder:", ROOT, "| limit:", LIMIT || "all", "| site:", SITE || "(not set — sitemap skipped)");
  let rows = await fromGBIF();
  if (!rows.length) throw new Error("GBIF returned nothing; aborting so the old data stays.");
  await enrich(rows);
  /* species with a photo first, then those with a common name; stable inside each group */
  const score = r => (r.file ? 2 : 0) + (r.en ? 1 : 0);
  rows = rows.map((r, i) => [r, i]).sort((a, b) => score(b[0]) - score(a[0]) || a[1] - b[1]).map(x => x[0]);
  if (LIMIT > 0) rows = rows.slice(0, LIMIT);
  rows.sort((a, b) => (a.order + a.family + a.sci).localeCompare(b.order + b.family + b.sci));
  const used = new Set();
  rows.forEach(r => { let s = slug(r.sci) || "sp"; let k = s, n = 2; while (used.has(k)) k = s + "-" + n++; used.add(k); r.slug = k; });

  fs.writeFileSync(path.join(ROOT, "birds.json"), JSON.stringify({ v: 1, built: new Date().toISOString(), n: rows.length,
    rows: rows.map(r => [r.sci, r.genus, r.family, r.order, r.gbif, r.fk, r.en, r.ar, r.file, r.wd]) }));
  const dir = path.join(ROOT, "birds"); fs.mkdirSync(dir, { recursive: true });
  for (const f of fs.readdirSync(dir)) if (f.endsWith(".html")) fs.unlinkSync(path.join(dir, f));
  rows.forEach(r => fs.writeFileSync(path.join(dir, r.slug + ".html"), pageHTML(r)));
  fs.writeFileSync(path.join(dir, "index.html"), indexHTML(rows));
  if (SITE) {
    const day = new Date().toISOString().slice(0, 10);
    const urls = [SITE + "/", SITE + "/birds/"].concat(rows.map(r => SITE + "/birds/" + r.slug + ".html"));
    fs.writeFileSync(path.join(ROOT, "sitemap.xml"), '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
      urls.map(u => "<url><loc>" + esc(u) + "</loc><lastmod>" + day + "</lastmod></url>").join("\n") + "\n</urlset>\n");
    fs.writeFileSync(path.join(ROOT, "robots.txt"), "User-agent: *\nAllow: /\n\nSitemap: " + SITE + "/sitemap.xml\n");
  }
  console.log("Done:", rows.length, "species,", rows.filter(r => r.file).length, "with photo,", rows.filter(r => r.ar).length, "with Arabic name.");
})().catch(e => { console.error("\nBUILD FAILED:", e.message); process.exit(1); });
